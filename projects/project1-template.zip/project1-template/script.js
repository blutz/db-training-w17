$(document).ready(function() {
  // Your Javascript code here
});
